#ifndef _hw4_a
#define _hw4_a

#include <string>

std::string sortByFreq(std::string s);

#endif