#include <string>
#include "sorta.h"

std::string sortByFreq(std::string s) {
	// ...
    // your code here
    // ...
    return {}; // you will need to change this
}