#include "escape_zoo.h"

motion_plan escape_route(grid const &M, coordinate init_coordinate, Heading init_heading) {

    // your implementation here

    return {}; // don't forget to change this
}
