#include "node.h"

// your includes here

bool isWeightBalanced(node* root, int k) { 

	// your implementation here

    return 0; // don't forget to upate this
}

// your helper methods here